#### Emlékeztető a _pull request_ használatáról

- A megoldásod a laborvezető fogja pontozni, ennél a labornál nincs automatikus értékelés.
- A laborvezetődhöz akkor rendeld a pull request-et, amikor készen vagy, és beadod a megoldást.
- Ne merge-eld a pull request-et.

A folyamatot részletesen lásd itt: <https://bmeviauac01.github.io/laborok/GitHub/>

#### A reminder how to use the _pull request_

- Your submission will be graded by the laboratory instructor. There is no automated evaluation here.
- Assign the pull request to the instructor once you are finished and ready to submit.
- Do not merge the pull request.

Please refer to the detailed guide here: <https://bmeviauac01.github.io/laboratories-en/GitHub/>